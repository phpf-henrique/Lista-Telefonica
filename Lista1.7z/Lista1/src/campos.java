public class campos {
 
 public String nome;
 public int tel;
 
 public campos(){
}
 
 public campos(String nome, int telefone){
 this.nome = nome;
 this.tel = telefone;
}
 
}